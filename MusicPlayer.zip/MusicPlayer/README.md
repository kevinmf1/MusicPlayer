# SampleMusicPlayer
Simple music player
## Intro
This project was due to a stack overflow request.

Then I decided, why make a simple audio player that can actually do stuff?

Since then, I have kept enjoying adding more features and fixing bugs thanks to all you guys.

Some code is a derivative of my other complex Music player project:

[BX Player](https://github.com/carloscj6/BXPlayer)
## Screenshots
<img src="/screenshots/screenshot" width="200px"> <img src="/screenshots/Screenshot_2019-02-14-13-17-12.png" width="200px">
<img src="/screenshots/Screenshot_2019-02-14-13-17-20.png" width="200px">

LICENSE
-------
    MIT License

    Copyright (c) 2019 Carlos Anyona
 Get full license [here](/LICENSE)
